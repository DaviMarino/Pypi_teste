class MeuNome:
  NOME = 'Davi'
